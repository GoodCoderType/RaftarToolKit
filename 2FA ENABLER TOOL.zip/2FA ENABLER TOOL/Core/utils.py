import base64
import json
import random
import re
import time
from pathlib import Path
from typing import Any, Dict
from uuid import uuid4

import requests
import yaml

class Utils:
    BUILD_RE = re.compile(r'"BUILD_NUMBER"\s*:\s*"?(\d+)"?')
    PROXY_PATH = "data/proxies.txt"
    DEFAULT_BUILD_NUMBER = 500334

    @classmethod
    def get_build_number(cls) -> int:
        try:
            response = requests.get("https://discord.com/login", timeout=5)
            response.raise_for_status()
            match = cls.BUILD_RE.search(response.text)
            return int(match.group(1)) if match else cls.DEFAULT_BUILD_NUMBER
        except requests.RequestException:
            return cls.DEFAULT_BUILD_NUMBER

    @staticmethod
    def load_config(path: str = "config.yaml") -> dict[str, Any]:
        try:
            with open(path, "r", encoding="utf-8") as f:
                return yaml.safe_load(f)
        except FileNotFoundError as exc:
            raise FileNotFoundError(f"Config file not found: {path}") from exc
        except yaml.YAMLError as exc:
            raise ValueError(f"Config file has invalid YAML: {path}") from exc

    @staticmethod
    def get_fingerprint(session):
        response = session.get(
            "https://discord.com/api/v9/experiments",
            timeout=10,
            )
        print(f"Fingerprint response: {response.status_code} - {response.text}")
        return response.json()["fingerprint"]
        
    @staticmethod
    def get_proxy(file_path: str = "data/proxies.txt") -> Dict[str, str]:
        path = Path(file_path)
        if not path.is_file():
            raise FileNotFoundError(f"Proxy file not found: {file_path}")
        
        with path.open(encoding="utf-8") as f:
            proxies: list[str] = []
            for raw in f:
                proxy = raw.strip()
                if not proxy or proxy.startswith("#"):
                    continue

                if not proxy.lower().startswith(("http://", "https://")):
                    proxy = "http://" + proxy
                proxies.append(proxy)
            
        if not proxies:
            raise ValueError("No proxies found in file")
        
        proxy = random.choice(proxies)
        return {"http": proxy, "https": proxy}

    @staticmethod
    def generate_xsuper(ua: str, build: int, chrome: int) -> str:
        payload = {
            "os": "Windows",
            "browser": "Chrome",
            "device": "",
            "system_locale": "en-US",
            "has_client_mods": False,
            "browser_user_agent": ua,
            "browser_version": f"{chrome}.0.0.0",
            "os_version": "10",
            "referrer": "",
            "referring_domain": "",
            "referrer_current": "https://discord.com/",
            "referring_domain_current": "discord.com",
            "release_channel": "stable",
            "client_build_number": build,
            "client_event_source": None,
            "client_launch_id": str(uuid4()),
            "launch_signature": str(uuid4()),
            "client_heartbeat_session_id": str(uuid4()),
            "client_app_state": "focused"
        }
        return base64.b64encode(json.dumps(payload, separators=(',', ':')).encode()).decode()
