import threading
from datetime import datetime
from colorama import Fore, init

init(autoreset=True)

COLOURS = {
    "BRIGHT_BLUE": "\033[1;38;5;39m",
    "BRIGHT_GREEN": "\033[1;38;5;82m",
    "BRIGHT_YELLOW": "\033[1;38;5;226m",
    "BRIGHT_RED": "\033[1;38;5;196m",
    "SOFT_MAGENTA": "\033[1;38;5;171m",
    "BRIGHT_PINK": "\033[1;38;5;213m",
    "BRIGHT_CYAN": "\033[1;38;5;51m",
    "BRIGHT_WHITE": "\033[1;97m",
    "DIM_GRAY": "\033[1;38;5;245m",
    "RESET": "\033[0m"
}

COLOUR_NAMES = list(COLOURS.keys())

BRIGHT_BLUE   = COLOURS["BRIGHT_BLUE"]
BRIGHT_GREEN  = COLOURS["BRIGHT_GREEN"]
BRIGHT_YELLOW = COLOURS["BRIGHT_YELLOW"]
BRIGHT_RED    = COLOURS["BRIGHT_RED"]
SOFT_MAGENTA  = COLOURS["SOFT_MAGENTA"]
BRIGHT_PINK   = COLOURS["BRIGHT_PINK"]
BRIGHT_CYAN   = COLOURS["BRIGHT_CYAN"]
BRIGHT_WHITE  = COLOURS["BRIGHT_WHITE"]
DIM_GRAY      = COLOURS["DIM_GRAY"]
RESET         = COLOURS["RESET"]


class HypeLogger:
    LEVEL_COLORS = {
        "INFO": BRIGHT_CYAN,
        "DEBUG": SOFT_MAGENTA,
        "SUCCESS": BRIGHT_GREEN,
        "WARNING": BRIGHT_YELLOW,
        "ERROR": BRIGHT_RED,
        "CRITICAL": BRIGHT_PINK,
    }

    def __init__(self, name: str = "HYPESTAR", version: str = None):
        self._lock = threading.RLock()
        self.name = name
        self.version = version
        prefix_parts = [f"{BRIGHT_CYAN}[{BRIGHT_BLUE}{self.name}{BRIGHT_CYAN}]"]
        if version is not None:
            prefix_parts.append(f"{BRIGHT_WHITE}v{version}{RESET}")
        self.prefix = " ".join(prefix_parts)

    def _format_time(self):
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        return f"{BRIGHT_CYAN}[{BRIGHT_BLUE}{now}{BRIGHT_CYAN}]"

    def _format_level(self, level: str):
        color = self.LEVEL_COLORS.get(level.upper(), BRIGHT_WHITE)
        return f"{SOFT_MAGENTA}[{color}{level.upper()}{SOFT_MAGENTA}]"

    def _format_extras(self, kwargs: dict, value_color: str):
        if not kwargs:
            return ""
        return " ".join(
            f"{BRIGHT_WHITE}{k}{DIM_GRAY}={value_color}{v}{RESET}" for k, v in kwargs.items()
        )

    def _log(self, level: str, message: str, *, elapsed=None,**kwargs):
        with self._lock:
            head = f"{self.prefix} {self._format_time()} {self._format_level(level)}"
            extras = self._format_extras(kwargs, self.LEVEL_COLORS.get(level.upper(), BRIGHT_WHITE))
            elapsed_txt = f" {DIM_GRAY}>> {BRIGHT_GREEN}{elapsed:.2f}s{RESET}" if elapsed is not None else ""
            final = f"{head} {BRIGHT_WHITE}{message}{RESET}"
            if extras:
                final += " " + extras
            final += elapsed_txt
            print(final + Fore.RESET, flush=True)

    def info(self, message, **kwargs):
        self._log("INFO", message, **kwargs)

    def debug(self, message, **kwargs):
        self._log("DEBUG", message, **kwargs)

    def success(self, message, **kwargs):
        self._log("SUCCESS", message, **kwargs)

    def warning(self, message, **kwargs):
        self._log("WARNING", message, **kwargs)

    def error(self, message, **kwargs):
        self._log("ERROR", message, **kwargs)

    def critical(self, message, **kwargs):
        self._log("CRITICAL", message, **kwargs)

    @staticmethod
    def list_colours():
        for name, code in COLOURS.items():
            print(f"{code}{name}{RESET}")

