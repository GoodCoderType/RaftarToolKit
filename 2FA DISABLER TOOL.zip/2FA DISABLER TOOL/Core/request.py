import ctypes
import os
import sys
import threading
import time
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Optional

import curl_cffi
import pyotp
from colorama import Fore, init

from Core.utils import Utils
from Core.logger import HypeLogger

init(autoreset=True)
log = HypeLogger(name="HYPESTAR", version="1.0.0")

try:
    config = Utils.load_config()
    GENERAL = config.get('general', {})
    PROXYLESS = GENERAL.get('proxyless', True)
    RETRIES = int(GENERAL.get('maxRequestRetries', 5))
    DEBUG_MODE = GENERAL.get('debugMode', False)
    DATED_OUTPUTS = GENERAL.get('datedOutput', False)
    WORKERS = int(GENERAL.get('maxThreads', 10))
except Exception as e:
    log.error(f'Config Error: {e}!')
    sys.exit(1)


@dataclass
class Tracker:
    success: int = 0
    failed: int = 0


tracker = Tracker()
tracker_lock = threading.RLock()
file_lock = threading.RLock()
thread_local = threading.local()


class Discord:
    def __init__(self):
        self.path = self._dated_outputs()
        self.masked = lambda token: f"{token[:24]}..." if token else "N/A"
        if os.name == "nt":
            threading.Thread(target=self._update_title, daemon=True).start()

    def _update_title(self):
        while True:
            with tracker_lock:
                title = f"2fa Disabler ~ Success: {tracker.success}, Failed: {tracker.failed}"
            try:
                ctypes.windll.kernel32.SetConsoleTitleW(title)
            except Exception:
                break
            time.sleep(2)

    def _dated_outputs(self) -> str:
        path = os.path.join('output', datetime.now().strftime("%Y-%m-%d_%H-%M-%S")) if DATED_OUTPUTS else 'output'
        os.makedirs(path, exist_ok=True)
        for fname in ("success.txt", "failed.txt"):
            full_path = os.path.join(path, fname)
            if not os.path.isfile(full_path):
                open(full_path, "a", encoding='utf-8').close()
        return path

    @staticmethod
    def _write_safely(line: str, file: str):
        with file_lock:
            directory = os.path.dirname(file)
            if directory:
                os.makedirs(directory, exist_ok=True)
            with open(file, 'a', encoding='utf-8') as f:
                f.write(line + '\n')

    @staticmethod
    def remove_safely(token: str, file_path='data/tokens.txt') -> bool:
        with file_lock:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                token = token.strip()
                filtered = [line for line in lines if line.strip() != token]
                if len(filtered) == len(lines):
                    return False
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.writelines(filtered)
                return True
            except Exception:
                return False

    def _get_session(self) -> curl_cffi.Session:
        if not hasattr(thread_local, "session"):
            sess = curl_cffi.Session(impersonate='chrome124', timeout=10)
            if not PROXYLESS:
                try:
                    sess.proxies = Utils.get_proxy()
                except Exception as e:
                    log.warning(f'Proxy disabled for thread: {e}')
            sess.headers.update({
                "accept": "*/*",
                "accept-language": "en-US,en;q=0.9",
                "accept-encoding": "gzip, deflate, br",
                "content-type": "application/json",
                "origin": "https://discord.com",
                "referer": "https://discord.com/channels/@me",
                "sec-ch-ua": '"Google Chrome";v="124", "Chromium";v="124", "Not.A/Brand";v="24"',
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-platform": '"Windows"',
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-origin",
                "x-discord-locale": "en-US",
            })
            ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
            try:
                xsuper = Utils.generate_xsuper(ua=ua, build=Utils.get_build_number(), chrome=124)
                fingerprint = Utils.get_fingerprint(sess)
            except Exception as e:
                log.error(f"Failed to generate fingerprint/xsuper: {e}")
                raise
            sess.headers.update({
                "user-agent": ua,
                "x-super-properties": xsuper,
                "x-fingerprint": fingerprint,
            })
            thread_local.session = sess
        return thread_local.session

    def _debug_mode(self, resp):
        if DEBUG_MODE:
            print(Fore.LIGHTWHITE_EX + '~ DEBUG MODE ~ started -> ' + Fore.RESET)
            print(f"Status: {getattr(resp, 'status_code', None)}")
            print(f"URL: {getattr(resp, 'url', None)}")
            print(f"Text: {getattr(resp, 'text', '')}")
            print(Fore.LIGHTWHITE_EX + '~ DEBUG MODE ~ Ended -> ' + Fore.RESET)

    def do_request(self, method: str, url: str, session: curl_cffi.Session = None,
                   json=None, headers=None, data=None, params=None,
                   allow_redirects=True, max_retry=None) -> curl_cffi.Response:
        if session is None:
            session = self._get_session()
        max_retry = RETRIES if max_retry is None else max_retry
        method_upper = method.upper()
        backoff = 0.5
        last_exception = None

        for attempt in range(max_retry):
            try:
                kwargs = {}
                if headers:
                    kwargs['headers'] = headers
                if params:
                    kwargs['params'] = params
                if method_upper not in {"GET", "HEAD"}:
                    if data is not None:
                        kwargs['data'] = data
                    if json is not None:
                        kwargs['json'] = json
                resp = session.request(
                    method_upper, url,
                    allow_redirects=allow_redirects,
                    **kwargs
                )
                self._debug_mode(resp)
                if resp.status_code == 429:
                    retry_after = resp.json().get('retry_after', 1)
                    time.sleep(retry_after)
                    continue
                return resp
            except Exception as exc:
                last_exception = exc
                if attempt == max_retry - 1:
                    break
                time.sleep(min(backoff, 8))
                backoff *= 1.5
        raise Exception(f"Request failed after {max_retry} attempts: {url} | {last_exception}")

    def _handle_mfa_challenge(self, session: curl_cffi.Session, mfa_response: dict, password: str = None, otp: str = None) -> Optional[str]:
        mfa = mfa_response.get('mfa', {})
        ticket = mfa.get('ticket')
        if not ticket:
            log.error("No MFA ticket in response")
            return None

        mfa_type = 'password' if password else 'totp'
        data = password or otp
        finish_data = {
            'ticket': ticket,
            'mfa_type': mfa_type,
            'data': data,
        }
        try:
            finish_resp = self.do_request(
                'POST', 'https://discord.com/api/v9/mfa/finish',
                session=session, json=finish_data
            )
        except Exception as e:
            log.error(f"MFA finish request failed: {e}")
            return None

        if finish_resp.status_code != 200:
            log.error(f"MFA finish failed: {finish_resp.text[:200]}")
            return None

        finish_json = self._safe_json(finish_resp)
        return finish_json.get('token')

    @staticmethod
    def _safe_json(resp) -> dict:
        try:
            return resp.json()
        except Exception:
            return {}

    def _fail(self, token_line: str, masked: str, msg: str, filename: str = "failed.txt"):
        with tracker_lock:
            tracker.failed += 1
        log.error(msg, token=masked)
        self._write_safely(token_line, os.path.join(self.path, filename))
        self.remove_safely(token_line)
        return False

    def twofa_disabler(self, token_line: str) -> bool:
        parts = [p.strip() for p in token_line.split(':')]
        if len(parts) < 4:
            return self._fail(token_line, "N/A", "Invalid format: need email:pass:token:2fa")

        email, password, token, base32_secret = parts[:4]
        masked = self.masked(token)
        session = self._get_session()
        session.headers.update({"authorization": token})

        try:
            resp = self.do_request(
                'POST', 'https://discord.com/api/v9/users/@me/mfa/totp/disable',
                session=session
            )
        except Exception as e:
            return self._fail(token_line, masked, f"Disable request failed: {e}")

        status = resp.status_code
        resp_json = self._safe_json(resp)

        if status in (200, 201):
            new_token = resp_json.get('token', token)
            with tracker_lock:
                tracker.success += 1
            log.success(f"2FA Disabled! {masked}")
            self._write_safely(
                f"{email}:{password}:{new_token}",
                os.path.join(self.path, "success.txt")
            )
            self.remove_safely(token_line)
            return True

        if status == 401:
            otp = pyotp.TOTP(base32_secret).now()
            ticket = self._handle_mfa_challenge(session, resp_json, otp=otp)
            if not ticket:
                return self._fail(token_line, masked, "MFA TOTP challenge failed")

            try:
                resp2 = self.do_request(
                    'POST', 'https://discord.com/api/v9/users/@me/mfa/totp/disable',
                    session=session, headers={'X-Discord-MFA-Authorization': ticket}
                )
            except Exception as e:
                return self._fail(token_line, masked, f"Second disable failed: {e}")

            if resp2.status_code in (200, 201):
                resp2_json = self._safe_json(resp2)
                new_token = resp2_json.get('token', token)
                with tracker_lock:
                    tracker.success += 1
                log.success(f"2FA Disabled! {masked}")
                self._write_safely(
                    f"{email}:{password}:{new_token}",
                    os.path.join(self.path, "success.txt")
                )
                self.remove_safely(token_line)
                return True
            else:
                err_msg = self._safe_json(resp2).get('message', resp2.text[:200])
                return self._fail(token_line, masked, f"Disable failed: {err_msg}")

        err_msg = resp_json.get('message', resp.text[:200])
        return self._fail(token_line, masked, f"Disable failed: {err_msg}")

    def process_tokens(self):
        token_file = 'data/tokens.txt'
        if not os.path.exists(token_file):
            log.error(f"Token file not found: {token_file}")
            return None

        with open(token_file, 'r', encoding='utf-8') as f:
            tokens = [line.strip() for line in f if line.strip()]

        if not tokens:
            log.error("No tokens found in file")
            return None

        def worker(token_line: str):
            try:
                return self.twofa_disabler(token_line) 
            except Exception as e:
                log.error(f"Unexpected error: {e}")
                with tracker_lock:
                    tracker.failed += 1
                return False

        max_workers = max(1, min(len(tokens), WORKERS))
        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            list(pool.map(worker, tokens))

        return {
            'processed': tracker.success + tracker.failed,
            'success': tracker.success,
            'failed': tracker.failed
        }