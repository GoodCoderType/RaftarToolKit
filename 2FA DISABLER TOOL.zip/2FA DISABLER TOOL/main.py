from Core.request import Discord
from colorama import Fore, init; init(autoreset=True)
def main():
    logo = '''
\t\t╦ ╦╦ ╦╔═╗╔═╗╔═╗╔═╗╔═╗╔═╗
\t\t╠═╣╚╦╝╠═╝║╣ ╚═╗╠═╝╠═╣╠╦╝
\t\t╩ ╩ ╩ ╩  ╚═╝╚═╝╩  ╩ ╩╩╚═
    '''
    print(logo)
    discord = Discord()

    result = discord.process_tokens()
    print('\n\n')
    if not result:
        return
    
    print(f"{Fore.LIGHTWHITE_EX}Processed: {Fore.RESET}{Fore.LIGHTCYAN_EX}{result['processed']}{Fore.RESET}")
    print(f"{Fore.LIGHTWHITE_EX}Success: {Fore.RESET}{Fore.LIGHTGREEN_EX}{result['success']}{Fore.RESET}")
    print(f"{Fore.LIGHTWHITE_EX}Failed: {Fore.RESET}{Fore.LIGHTCYAN_EX}{result['failed']}{Fore.RESET}")

if "__main__" == __name__:
    main()